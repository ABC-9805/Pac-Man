import random
import pyxel
import time


class Fruits:
    def __init__(self, board):
        self.board = board  # Reference to the board
        self.width = 16
        self.height = 16
        self.predefined_positions = [(486, 514), (36, 514), (486, 90), (36, 90),(263,432), (263,540), (263,108)]  # Coordenadas fijas
        self.x, self.y = self.get_random_position()
        self.type = random.randint(1, 4)  # Assign a random type of fruit (1 to 4)
        self.visible = True  # Visibility state of the fruit
        self.spawn_time = time.time()  # Tells the time when the fruit was created

    def get_random_position(self):
        # Chooses randomly one of the predefined positions
        return random.choice(self.predefined_positions)

    def update(self):
        """Manages the visibility of the fruit according to the timers."""
        current_time = time.time()

        # If it is visible amnd 5 seconds have passed, it disappears
        if self.visible and current_time - self.spawn_time >= 10:
            self.visible = False
            self.spawn_time = current_time  # Resets the timer

        # If it is hidden and 10 seconds have passed since its disappearance, it reappears.
        elif not self.visible and current_time - self.spawn_time >= 10:
            self.spawn_random()
            self.visible = True
            self.spawn_time = current_time  # Resets the timer

    def spawn_random(self):
        """Relocate the fruit to a new random position."""
        self.x, self.y = self.get_random_position()
        self.type = random.randint(1, 4)  # Changes the fruit type


    def draw(self):
        """Draw the fruit if it is visible."""
        if self.visible:
            if self.type == 1:
                pyxel.blt(self.x, self.y, 0, 0, 80, self.width, self.height, 0)  # Fruta 1
            elif self.type == 2:
                pyxel.blt(self.x, self.y, 0, 16, 80, self.width, self.height, 0)  # Fruta 2
            elif self.type == 3:
                pyxel.blt(self.x, self.y, 0, 32, 80, self.width, self.height, 0)  # Fruta 3
            elif self.type == 4:
                pyxel.blt(self.x, self.y, 0, 48, 80, self.width, self.height, 0)  # Fruta 4