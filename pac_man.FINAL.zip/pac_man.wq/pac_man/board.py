import pyxel
from pac_man import Pacman
from Ghost import ghost1, ghost2, ghost3, ghost4
from Fruits import Fruits

class Board:
    def __init__(self, width: int, height: int):
        # initializes private attributes once
        self._width = width
        self._height = height
        pyxel.init(self._width, self._height, title="Pac-Man")  # Initialize the window once
        self._pacman = Pacman()
        self._ghost1, self._ghost2, self._ghost3, self._ghost4 = ghost1(), ghost2(),ghost3(), ghost4()
        self._ghosts = [self._ghost1, self._ghost2, self._ghost3, self._ghost4]
        self.boards = [
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [3, 6, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5, 6, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5, 3],
            [3, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 3],
            [3, 3, 1, 6, 4, 4, 5, 1, 6, 4, 4, 4, 5, 1, 3, 3, 1, 6, 4, 4, 4, 5, 1, 6, 4, 4, 5, 1, 3, 3],
            [3, 3, 2, 3, 4, 4, 3, 1, 3, 4, 4, 4, 3, 1, 3, 3, 1, 3, 4, 4, 4, 3, 1, 3, 4, 4, 3, 2, 3, 3],
            [3, 3, 1, 7, 4, 4, 8, 1, 7, 4, 4, 4, 8, 1, 7, 8, 1, 7, 4, 4, 4, 8, 1, 7, 4, 4, 8, 1, 3, 3],
            [3, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 3],
            [3, 3, 1, 6, 4, 4, 5, 1, 6, 5, 1, 6, 4, 4, 4, 4, 4, 4, 5, 1, 6, 5, 1, 6, 4, 4, 5, 1, 3, 3],
            [3, 3, 1, 7, 4, 4, 8, 1, 3, 3, 1, 7, 4, 4, 5, 6, 4, 4, 8, 1, 3, 3, 1, 7, 4, 4, 8, 1, 3, 3],
            [3, 3, 1, 1, 1, 1, 1, 1, 3, 3, 1, 1, 1, 1, 3, 3, 1, 1, 1, 1, 3, 3, 1, 1, 1, 1, 1, 1, 3, 3],
            [3, 7, 4, 4, 4, 4, 5, 1, 3, 7, 4, 4, 5, 0, 3, 3, 0, 6, 4, 4, 8, 3, 1, 6, 4, 4, 4, 4, 8, 3],
            [3, 4, 4, 4, 4, 4, 3, 1, 3, 6, 4, 4, 8, 0, 7, 8, 0, 7, 4, 4, 5, 3, 1, 3, 4, 4, 4, 4, 4, 3],
            [3, 4, 4, 4, 4, 4, 3, 1, 3, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 3, 1, 3, 4, 4, 4, 4, 4, 3],
            [8, 4, 4, 4, 4, 4, 3, 1, 3, 3, 0, 6, 4, 4, 9, 9, 4, 4, 5, 0, 3, 3, 1, 3, 4, 4, 4, 4, 4, 7],
            [4, 4, 4, 4, 4, 4, 8, 1, 7, 8, 0, 3, 0, 0, 0, 0, 0, 0, 3, 0, 7, 8, 1, 7, 4, 4, 4, 4, 4, 4],
            [0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0],
            [4, 4, 4, 4, 4, 4, 5, 1, 6, 5, 0, 3, 0, 0, 0, 0, 0, 0, 3, 0, 6, 5, 1, 6, 4, 4, 4, 4, 4, 4],
            [5, 4, 4, 4, 4, 4, 3, 1, 3, 3, 0, 7, 4, 4, 4, 4, 4, 4, 8, 0, 3, 3, 1, 3, 4, 4, 4, 4, 4, 6],
            [3, 4, 4, 4, 4, 4, 3, 1, 3, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 3, 1, 3, 4, 4, 4, 4, 4, 3],
            [3, 4, 4, 4, 4, 4, 3, 1, 3, 3, 0, 6, 4, 4, 4, 4, 4, 4, 5, 0, 3, 3, 1, 3, 4, 4, 4, 4, 4, 3],
            [3, 6, 4, 4, 4, 4, 8, 1, 7, 8, 0, 7, 4, 4, 5, 6, 4, 4, 8, 0, 7, 8, 1, 7, 4, 4, 4, 4, 5, 3],
            [3, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 3],
            [3, 3, 1, 6, 4, 4, 5, 1, 6, 4, 4, 4, 5, 1, 3, 3, 1, 6, 4, 4, 4, 5, 1, 6, 4, 4, 5, 1, 3, 3],
            [3, 3, 1, 7, 4, 5, 3, 1, 7, 4, 4, 4, 8, 1, 7, 8, 1, 7, 4, 4, 4, 8, 1, 3, 6, 4, 8, 1, 3, 3],
            [3, 3, 2, 1, 1, 3, 3, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 3, 3, 1, 1, 2, 3, 3],
            [3, 7, 4, 5, 1, 3, 3, 1, 6, 5, 1, 6, 4, 4, 4, 4, 4, 4, 5, 1, 6, 5, 1, 3, 3, 1, 6, 4, 8, 3],
            [3, 6, 4, 8, 1, 7, 8, 1, 3, 3, 1, 7, 4, 4, 5, 6, 4, 4, 8, 1, 3, 3, 1, 7, 8, 1, 7, 4, 5, 3],
            [3, 3, 1, 1, 1, 1, 1, 1, 3, 3, 1, 1, 1, 1, 3, 3, 1, 1, 1, 1, 3, 3, 1, 1, 1, 1, 1, 1, 3, 3],
            [3, 3, 1, 6, 4, 4, 4, 4, 8, 7, 4, 4, 5, 1, 3, 3, 1, 6, 4, 4, 8, 7, 4, 4, 4, 4, 5, 1, 3, 3],
            [3, 3, 1, 7, 4, 4, 4, 4, 4, 4, 4, 4, 8, 1, 7, 8, 1, 7, 4, 4, 4, 4, 4, 4, 4, 4, 8, 1, 3, 3],
            [3, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 3],
            [3, 7, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 8, 3],
            [7, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 8]
        ]
        self.game_started = False
        self.start_time = pyxel.frame_count  # Game start indicator
        self._fruits = Fruits(self) #create fruits object
        self.fruit_timer = 600  # 10 seconds in frames (60 FPS)
        self.fruit_spawned = False #indicator for whether fruit has spawned
        pyxel.load("assets/pacman.pyxres") #load the graphical assets
        pyxel.run(self.update, self.draw) #run the game loop with update
    # Property para width
    @property
    def width(self):
        return self._width
    @width.setter
    def width(self, value: int):
        if value > 0:
            self._width = value
            # Set the width, without reinitializing pyxel
    @property
    def height(self):
        return self._height
    @height.setter
    def height(self, value: int):
        if value > 0:
            self._height = value # Set the height, without reinitializing pyxel

    def run_game(self):
        # Configures the update and draw loop for the game
        pyxel.run(self.update, self.draw)


    def update(self):
        # If the game has not started, show the start screen
        if not self.game_started:
            if pyxel.btnp(pyxel.KEY_W):  # Start the game by pressing 'W'
                self.game_started = True
            return  # Do not continue updating until the game starts

        # Check if 'Q' key is pressed to quit the game
        if pyxel.btnp(pyxel.KEY_Q):
            pyxel.quit() #quit the game
            return

        # **Fruit timer**
        if not self.fruit_spawned:
            if self.fruit_timer > 0:
                self.fruit_timer -= 1  # Decrease the countdown timer
            else:
                self._fruits.spawn_random()  # Spawn fruit on the board
                self.fruit_spawned = True  #Mark fruit as spawned
        else:
            self._fruits.update()  # Update fruit state

        # **Verify if the countdown is active**
        if self._pacman.countdown_timer > 0:
            self._pacman.countdown_timer -= 1  # Decrease the countdown timer
        else:
            # **Move pac-man and verify collisions when the countdown has finished**
            self._pacman.move(self.boards, self._ghosts)
            self._pacman.check_collision(self._ghosts, self._fruits)


        # **Update every ghost**
        for ghost in self._ghosts:
            ghost.update(self.boards, self._pacman.x, self._pacman.y, self.game_started)


    def draw_text_large(self, x, y, text, color):
        # Map of pyxel characters
        char_map = {
             "W": ["#     #", "#     #", "#  #  #", "#  #  #", " ## ## "],
            "E": ["######", "#     ", "##### ", "#     ", "######"],
            "L": ["#     ", "#     ", "#     ", "#     ", "######"],
            "C": [" #### ", "#     ", "#     ", "#     ", " #### "],
            "O": [" #### ", "#    #", "#    #", "#    #", " #### "],
            "M": ["#     #", "##   ##", "# # # #", "#  #  #", "#     #"],
            "P": ["##### ", "#    #", "##### ", "#     ", "#     "],
            "R": ["##### ", "#    #", "##### ", "#  #  ", "#   # "],
            "S": [" #####", "#     ", " #### ", "     #", "##### "],
            "T": ["######", "  ##  ", "  ##  ", "  ##  ", "  ##  "],
            "A": ["  ###  ", " #   # ", "#     #", "#######", "#     #"],
            " ": ["      ", "      ", "      ", "      ", "      "],
        }

        # Draw text character by character
        for char_index, char in enumerate(text):
            if char in char_map:
                for row_index, row in enumerate(char_map[char]):
                    for col_index, pixel in enumerate(row):
                        if pixel == "#":
                            # Size of big blocks
                            pyxel.rect(
                                x + col_index * 4 + char_index * 30,  # Space between characters
                                y + row_index * 4,  # Space between rows
                                4,  # Width of big pyxel
                                4,  # Height of big pyxel
                                color)

    def draw(self):
        # Draw the background in black
        pyxel.cls(0)
        if not self.game_started:
            text = "WELCOME"
            text_width = len(text) * 28  # SPace between characters
            x = (540 - text_width) // 2
            y = 200  # Adjus height when needed
            self.draw_text_large(x, y, text, pyxel.COLOR_YELLOW)

            # Instruction: "PRESS W TO START"
            instruction = "PRESS W TO START"
            instruction_width = len(instruction) * 28
            x_instruction = (540 - instruction_width) // 2
            y_instruction = y + 80  # Separation between text
            self.draw_text_large(x_instruction, y_instruction, instruction, pyxel.COLOR_WHITE)

        else:

            pyxel.load("assets/pacman.pyxres")  # Load pyxres

            # Cell size of 8x8 píxeles
            cell_size = 18

            # Draw the maze based on board
            for y, row in enumerate(self.boards):
                for x, cell in enumerate(row):
                    # Define the position in the board
                    pos_x = x * cell_size
                    pos_y = y * cell_size
                    if cell == 0:
                        pyxel.rect(pos_x, pos_y, cell_size, cell_size, 0)  # Black
                    elif cell == 1:
                        pyxel.circ(pos_x + cell_size // 2, pos_y + cell_size // 2,1, 9)  # Dot
                    elif cell == 2:
                        pyxel.circ(pos_x + cell_size // 2, pos_y + cell_size // 2,2, 10)  # Big dot
                    elif cell == 3:
                        pyxel.rect(pos_x, pos_y, cell_size, cell_size, 12)  # Vertical line
                    elif cell == 4:
                        pyxel.rect(pos_x, pos_y, cell_size, cell_size, 12)  # Horizontal line
                    elif cell == 5:
                        pyxel.rect(pos_x, pos_y, cell_size, cell_size, 12)  # Right up corner
                    elif cell == 6:
                        pyxel.rect(pos_x, pos_y, cell_size, cell_size, 12)  # Left up corner
                    elif cell == 7:
                        pyxel.rect(pos_x, pos_y, cell_size, cell_size, 12)  # Left down corner
                    elif cell == 8:
                        pyxel.rect(pos_x, pos_y, cell_size, cell_size, 12)  # Right down corner
                    elif cell == 9:
                        pyxel.rect(pos_x, pos_y+8, 18, 2, 7)  # Door

            #DRAW PACMAN
            self._pacman.draw()
            for ghost in self._ghosts:
                ghost.draw()
            if self.fruit_spawned:
                self._fruits.draw()

            # Show the countdown if active
            if self._pacman.countdown_timer > 0:
                countdown_number = self._pacman.countdown_timer // 60 + 1
                pyxel.text(260, 250, "READY!", 7,None)
                pyxel.text(270, 290, f"{countdown_number}", 7, None)  # Adjusts the position and color depending on the board


