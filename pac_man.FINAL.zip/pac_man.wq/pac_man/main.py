import pyxel  # Import the Pyxel library for creating 8-bit games
from board import Board  # Import the Board class from the 'board' module
from Level import Level  # Import the Level class from the 'Level' module

# Set the screen width and height
screen_width = 540
screen_height = 576
# Size of the screen (540x576 pixels)

# Create an instance of the Board class with the specified screen size
board = Board(screen_width, screen_height)

# Run the Pyxel game loop, calling the 'update' and 'draw' methods from the 'board' object
pyxel.run(board.update, board.draw)

# Load game assets (e.g., sprites, sounds) from the 'pacman.pyxres' resource file
pyxel.load("assets/pacman.pyxres")






