import pyxel


class Pacman:
    def __init__(self, x: int = 263, y: int = 432):
        self.x = x  # Posición inicial de Pac-Man
        self.y = y
        self.width = 16  # Ancho de la imagen de Pac-Man
        self.height = 16  # Alto de la imagen de Pac-Man
        self.dx = 2  # Movimiento horizontal (2 píxeles por frame)
        self.dy = 0 # Movimiento vertical (inicialmente no se mueve verticalmente)
        self.score = 0
        self.lives = 3
        self.countdown_timer = 0

    def move(self, boards):
        if self.countdown_timer > 0:
            self.countdown_timer -= 1
            return

        prev_dx, prev_dy = self.dx, self.dy
        next_dx, next_dy = self.dx, self.dy

        if pyxel.btn(pyxel.KEY_RIGHT):
            next_dx, next_dy = 2, 0
        elif pyxel.btn(pyxel.KEY_LEFT):
            next_dx, next_dy = -2, 0
        elif pyxel.btn(pyxel.KEY_UP):
            next_dx, next_dy = 0, -2
        elif pyxel.btn(pyxel.KEY_DOWN):
            next_dx, next_dy = 0, 2

        if next_dx != self.dx or next_dy != self.dy:
            if next_dx != 0:
                self.y = (self.y // 18) * 18
            elif next_dy != 0:
                self.x = (self.x // 18) * 18

        next_x = self.x + next_dx
        next_y = self.y + next_dy

        next_cell_x = (next_x + (16 if next_dx > 0 else 0)) // 18
        next_cell_y = (next_y + (16 if next_dy > 0 else 0)) // 18

        if boards[next_cell_y][next_cell_x] in [0, 1, 2]:
            self.x = next_x
            self.y = next_y
            self.dx, self.dy = next_dx, next_dy

            if boards[next_cell_y][next_cell_x] == 1:
                self.score += 10
                boards[next_cell_y][next_cell_x] = 0
            elif boards[next_cell_y][next_cell_x] == 2:
                self.score += 50
                boards[next_cell_y][next_cell_x] = 0
        else:
            self.dx, self.dy = prev_dx, prev_dy

        if self.x >= 522 and self.dx > 0:
            self.x = 1
        elif self.x < 0:
            self.x = 540 - 1

    def check_collision(self, ghosts):
        for ghost in ghosts:
            if abs(self.x - ghost.x) < 16 and abs(self.y - ghost.y) < 16:
                self.lives -= 1
                ghost.reset_position()
                self.start_countdown()
                if self.lives <= 0:
                    print("Game Over")
                    pyxel.quit()

    def start_countdown(self):
        self.countdown_timer = 180

    def update(self, boards, ghosts):
        self.move(boards)
        self.check_collision(ghosts)

    def draw(self):
        # Dibuja Pac-Man
        pyxel.blt(self.x, self.y, 0, 16, 0, self.width, self.height, colkey=0)
        # Llama a la función para dibujar "Score" en letras grandes
        pyxel.text(8, 6, f"SCORE:{self.score}", 7, None)
        pyxel.text(8, 20, f"LIVES:{self.lives}", 7, None)  # Dibujar vidas
