import pyxel
from board import Board


screen_width = 540
screen_height = 576
# Tamaño de la pantalla
board = Board(screen_width, screen_height)
pyxel.run(board.update, board.draw)
# Carga los assets
pyxel.load("assets/pacman.pyxres")

