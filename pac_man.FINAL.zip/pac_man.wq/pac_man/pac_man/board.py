import pyxel
from pac_man import Pacman
from Ghost import ghost1, ghost2, ghost3, ghost4
class Board:
    def __init__(self, width: int, height: int):
        # Inicializa los atributos privados solo una vez
        self._width = width
        self._height = height
        pyxel.init(self._width, self._height, title="Pac-Man")  # Inicializa la ventana una sola vez
        self._pacman = Pacman()
        self._ghost1, self._ghost2, self._ghost3, self._ghost4 = ghost1(), ghost2(),ghost3(), ghost4()
        self._ghosts = [self._ghost1, self._ghost2, self._ghost3, self._ghost4]
        self.boards = [
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [3, 6, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5, 6, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5, 3],
            [3, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 3],
            [3, 3, 1, 6, 4, 4, 5, 1, 6, 4, 4, 4, 5, 1, 3, 3, 1, 6, 4, 4, 4, 5, 1, 6, 4, 4, 5, 1, 3, 3],
            [3, 3, 2, 3, 4, 4, 3, 1, 3, 4, 4, 4, 3, 1, 3, 3, 1, 3, 4, 4, 4, 3, 1, 3, 4, 4, 3, 2, 3, 3],
            [3, 3, 1, 7, 4, 4, 8, 1, 7, 4, 4, 4, 8, 1, 7, 8, 1, 7, 4, 4, 4, 8, 1, 7, 4, 4, 8, 1, 3, 3],
            [3, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 3],
            [3, 3, 1, 6, 4, 4, 5, 1, 6, 5, 1, 6, 4, 4, 4, 4, 4, 4, 5, 1, 6, 5, 1, 6, 4, 4, 5, 1, 3, 3],
            [3, 3, 1, 7, 4, 4, 8, 1, 3, 3, 1, 7, 4, 4, 5, 6, 4, 4, 8, 1, 3, 3, 1, 7, 4, 4, 8, 1, 3, 3],
            [3, 3, 1, 1, 1, 1, 1, 1, 3, 3, 1, 1, 1, 1, 3, 3, 1, 1, 1, 1, 3, 3, 1, 1, 1, 1, 1, 1, 3, 3],
            [3, 7, 4, 4, 4, 4, 5, 1, 3, 7, 4, 4, 5, 0, 3, 3, 0, 6, 4, 4, 8, 3, 1, 6, 4, 4, 4, 4, 8, 3],
            [3, 4, 4, 4, 4, 4, 3, 1, 3, 6, 4, 4, 8, 0, 7, 8, 0, 7, 4, 4, 5, 3, 1, 3, 4, 4, 4, 4, 4, 3],
            [3, 4, 4, 4, 4, 4, 3, 1, 3, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 3, 1, 3, 4, 4, 4, 4, 4, 3],
            [8, 4, 4, 4, 4, 4, 3, 1, 3, 3, 0, 6, 4, 4, 9, 9, 4, 4, 5, 0, 3, 3, 1, 3, 4, 4, 4, 4, 4, 7],
            [4, 4, 4, 4, 4, 4, 8, 1, 7, 8, 0, 3, 0, 0, 0, 0, 0, 0, 3, 0, 7, 8, 1, 7, 4, 4, 4, 4, 4, 4],
            [0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0],
            [4, 4, 4, 4, 4, 4, 5, 1, 6, 5, 0, 3, 0, 0, 0, 0, 0, 0, 3, 0, 6, 5, 1, 6, 4, 4, 4, 4, 4, 4],
            [5, 4, 4, 4, 4, 4, 3, 1, 3, 3, 0, 7, 4, 4, 4, 4, 4, 4, 8, 0, 3, 3, 1, 3, 4, 4, 4, 4, 4, 6],
            [3, 4, 4, 4, 4, 4, 3, 1, 3, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 3, 1, 3, 4, 4, 4, 4, 4, 3],
            [3, 4, 4, 4, 4, 4, 3, 1, 3, 3, 0, 6, 4, 4, 4, 4, 4, 4, 5, 0, 3, 3, 1, 3, 4, 4, 4, 4, 4, 3],
            [3, 6, 4, 4, 4, 4, 8, 1, 7, 8, 0, 7, 4, 4, 5, 6, 4, 4, 8, 0, 7, 8, 1, 7, 4, 4, 4, 4, 5, 3],
            [3, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 3],
            [3, 3, 1, 6, 4, 4, 5, 1, 6, 4, 4, 4, 5, 1, 3, 3, 1, 6, 4, 4, 4, 5, 1, 6, 4, 4, 5, 1, 3, 3],
            [3, 3, 1, 7, 4, 5, 3, 1, 7, 4, 4, 4, 8, 1, 7, 8, 1, 7, 4, 4, 4, 8, 1, 3, 6, 4, 8, 1, 3, 3],
            [3, 3, 2, 1, 1, 3, 3, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 3, 3, 1, 1, 2, 3, 3],
            [3, 7, 4, 5, 1, 3, 3, 1, 6, 5, 1, 6, 4, 4, 4, 4, 4, 4, 5, 1, 6, 5, 1, 3, 3, 1, 6, 4, 8, 3],
            [3, 6, 4, 8, 1, 7, 8, 1, 3, 3, 1, 7, 4, 4, 5, 6, 4, 4, 8, 1, 3, 3, 1, 7, 8, 1, 7, 4, 5, 3],
            [3, 3, 1, 1, 1, 1, 1, 1, 3, 3, 1, 1, 1, 1, 3, 3, 1, 1, 1, 1, 3, 3, 1, 1, 1, 1, 1, 1, 3, 3],
            [3, 3, 1, 6, 4, 4, 4, 4, 8, 7, 4, 4, 5, 1, 3, 3, 1, 6, 4, 4, 8, 7, 4, 4, 4, 4, 5, 1, 3, 3],
            [3, 3, 1, 7, 4, 4, 4, 4, 4, 4, 4, 4, 8, 1, 7, 8, 1, 7, 4, 4, 4, 4, 4, 4, 4, 4, 8, 1, 3, 3],
            [3, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 3],
            [3, 7, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 8, 3],
            [7, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 8]
        ]
        pyxel.run(self.update, self.draw)
    # Property para width
    @property
    def width(self):
        return self._width
    @width.setter
    def width(self, value: int):
        if value > 0:
            self._width = value
            # Aquí no volvemos a llamar a pyxel.init, solo actualizamos el valor
    @property
    def height(self):
        return self._height
    @height.setter
    def height(self, value: int):
        if value > 0:
            self._height = value

    def run_game(self):
        # Configura el bucle de actualización y dibujo
        pyxel.run(self.update, self.draw)

    def update(self):
        if pyxel.btnp(pyxel.KEY_Q):
            pyxel.quit()
            return

        # Verificar si la cuenta atrás está activa
        if self._pacman.countdown_timer > 0:
            self._pacman.countdown_timer -= 1
        else:
            # Mover Pac-Man y verificar colisiones solo si la cuenta atrás ha terminado
            self._pacman.move(self.boards)
            self._pacman.check_collision(self._ghosts)

        # Actualizar todos los fantasmas
        for ghost in self._ghosts:
            ghost.update(self.boards, self._pacman.x, self._pacman.y)
    def draw(self):
        # Dibuja el fondo en negro
        pyxel.cls(0)

        pyxel.load("assets/pacman.pyxres")  # Carga de recursos

        # Tamaño de celda de 8x8 píxeles
        cell_size = 18

        # Dibujar el tablero usando los valores de `boards`
        for y, row in enumerate(self.boards):
            for x, cell in enumerate(row):
                # Definir la posición en pantalla según la celda
                pos_x = x * cell_size
                pos_y = y * cell_size
                if cell == 0:
                    pyxel.rect(pos_x, pos_y, cell_size, cell_size, 0)  # Negro
                elif cell == 1:
                    pyxel.circ(pos_x + cell_size // 2, pos_y + cell_size // 2,1, 9)  # Punto
                elif cell == 2:
                    pyxel.circ(pos_x + cell_size // 2, pos_y + cell_size // 2,2, 10)  # Punto grande
                elif cell == 3:
                    pyxel.rect(pos_x, pos_y, cell_size, cell_size, 12)  # Línea vertical
                elif cell == 4:
                    pyxel.rect(pos_x, pos_y, cell_size, cell_size, 12)  # Línea horizontal
                elif cell == 5:
                    pyxel.rect(pos_x, pos_y, cell_size, cell_size, 12)  # Esquina superior derecha
                elif cell == 6:
                    pyxel.rect(pos_x, pos_y, cell_size, cell_size, 12)  # Esquina superior izquierda
                elif cell == 7:
                    pyxel.rect(pos_x, pos_y, cell_size, cell_size, 12)  # Esquina inferior izquierda
                elif cell == 8:
                    pyxel.rect(pos_x, pos_y, cell_size, cell_size, 12)  # Esquina inferior derecha
                elif cell == 9:
                    pyxel.rect(pos_x, pos_y+8, 18, 2, 7)  # Puerta

        #DRAW PACMAN
        self._pacman.draw()
        self._ghost1.draw()
        self._ghost2.draw()
        self._ghost3.draw()
        self._ghost4.draw()
        # Mostrar la cuenta atrás si está activa
        if self._pacman.countdown_timer > 0:
            countdown_number = self._pacman.countdown_timer // 60 + 1
            pyxel.text(260, 250, "READY!", 7,None)
            pyxel.text(270, 290, f"{countdown_number}", 7, None)  # Ajusta la posición y el color según tu pantalla

