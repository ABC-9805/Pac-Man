import pyxel
import random



class ghost1:
    def __init__(self, x: int = 263, y: int = 216):
        self.x = x
        self.y = y
        self.width = 16
        self.height = 16
        self.dx = 2
        self.dy = 0
        self.stopped = False
        self.stopped_timer = 300
    def move(self, boards, pacman_x, pacman_y):
        if self.stopped and self.stopped_timer > 0:
            self.stopped_timer -= 1
            if self.stopped_timer == 0:
                self.stopped = False
            return

        next_x = self.x + self.dx
        next_y = self.y + self.dy

        next_cell_x = (next_x + (16 if self.dx > 0 else 0)) // 18
        next_cell_y = (next_y + (16 if self.dy > 0 else 0)) // 18

        if boards[next_cell_y][next_cell_x] in [0, 1, 2]:
            self.x = next_x
            self.y = next_y
        else:
            self.change_direction(pacman_x, pacman_y, boards)

        if self.x >= 522 and self.dx > 0:
            self.x = 1
        elif self.x < 0:
            self.x = 540 - 1

    def change_direction(self, pacman_x, pacman_y, boards):
        directions = [(2, 0), (-2, 0), (0, 2), (0, -2)]
        random.shuffle(directions)

        if abs(self.x - pacman_x) > abs(self.y - pacman_y):
            if self.x < pacman_x:
                directions.insert(0, (2, 0))
            else:
                directions.insert(0, (-2, 0))
        else:
            if self.y < pacman_y:
                directions.insert(0, (0, 2))
            else:
                directions.insert(0, (0, -2))

        for dx, dy in directions:
            next_x = self.x + dx
            next_y = self.y + dy
            next_cell_x = (next_x + (16 if dx > 0 else 0)) // 18
            next_cell_y = (next_y + (16 if dy > 0 else 0)) // 18

            if boards[next_cell_y][next_cell_x] in [0, 1, 2]:
                self.dx, self.dy = dx, dy
                return

        self.dx, self.dy = 0, 0

    def reset_position(self):
        self.x = 263
        self.y = 216
        self.stopped = True
        self.stopped_timer = 180  # 3 segundos detenido

    def update(self, boards, pacman_x, pacman_y):
        self.move(boards, pacman_x, pacman_y)

    def draw(self):
        pyxel.blt(self.x, self.y, 1, 16, 0, 16, 16, colkey=0)
class ghost2:
    def __init__(self, x: int = 263, y: int = 270):
        self.x = x  # Posición inicial del fantasma
        self.y = y
        self.width = 16  # Ancho de la imagen
        self.height = 16  # Alto de la imagen
        self.dx = 2  # Movimiento horizontal
        self.dy = 0
        self.start_time = pyxel.frame_count + 200
        self.target_x = 263  # Coordenada objetivo
        self.target_y = 216
        self.reached_target = False  # Indica si ha alcanzado el objetivo
        self.stopped = False
        self.stopped_timer = 300
    def move(self, boards, pacman_x, pacman_y):
        # Esperar hasta que hayan pasado 5 segundos
        if pyxel.frame_count < self.start_time:
            return

        # Moverse hacia el objetivo inicial si no ha llegado aún
        if not self.reached_target:
            self.move_to_target(boards)
            return

        if self.stopped and self.stopped_timer > 0:
            self.stopped_timer -= 1
            if self.stopped_timer == 0:
                self.stopped = False
            return

        next_x = self.x + self.dx
        next_y = self.y + self.dy

        next_cell_x = (next_x + (16 if self.dx > 0 else 0)) // 18
        next_cell_y = (next_y + (16 if self.dy > 0 else 0)) // 18

        if boards[next_cell_y][next_cell_x] in [0, 1, 2]:
            self.x = next_x
            self.y = next_y
        else:
            self.change_direction(pacman_x, pacman_y, boards)

        if self.x >= 522 and self.dx > 0:
            self.x = 1
        elif self.x < 0:
            self.x = 540 - 1
    def move_to_target(self, boards):
        # Moverse hacia la coordenada (263, 216)
        if self.x < self.target_x:
            self.dx, self.dy = 2, 0
        elif self.x > self.target_x:
            self.dx, self.dy = -2, 0
        elif self.y < self.target_y:
            self.dx, self.dy = 0, 2
        elif self.y > self.target_y:
            self.dx, self.dy = 0, -2

        # Calcular la siguiente posición
        next_x = self.x + self.dx
        next_y = self.y + self.dy
        next_cell_x = (next_x + (16 if self.dx > 0 else 0)) // 18
        next_cell_y = (next_y + (16 if self.dy > 0 else 0)) // 18

        # Verificar si la siguiente posición es válida (permitir celdas 0, 1, 2 y 9)
        if boards[next_cell_y][next_cell_x] in [0, 1, 2, 9]:
            self.x = next_x
            self.y = next_y

        # Verificar si ha alcanzado el objetivo
        if self.x == self.target_x and self.y == self.target_y:
            self.reached_target = True  # Ha alcanzado el objetivo

    def change_direction(self, pacman_x, pacman_y, boards):
        directions = [(2, 0), (-2, 0), (0, 2), (0, -2)]
        random.shuffle(directions)

        if abs(self.x - pacman_x) > abs(self.y - pacman_y):
            if self.x < pacman_x:
                directions.insert(0, (2, 0))
            else:
                directions.insert(0, (-2, 0))
        else:
            if self.y < pacman_y:
                directions.insert(0, (0, 2))
            else:
                directions.insert(0, (0, -2))

        for dx, dy in directions:
            next_x = self.x + dx
            next_y = self.y + dy
            next_cell_x = (next_x + (16 if dx > 0 else 0)) // 18
            next_cell_y = (next_y + (16 if dy > 0 else 0)) // 18

            if boards[next_cell_y][next_cell_x] in [0, 1, 2]:
                self.dx, self.dy = dx, dy
                return

        self.dx, self.dy = 0, 0
    def reset_position(self):
        self.x = 263
        self.y = 270
        self.dx = 2
        self.dy = 0
        self.stopped = True
        self.stopped_timer = 180  # 3 segundos detenido
        self.reached_target = False  # Reinicia el estado de objetivo
        self.target_x, self.target_y = 263, 216  # Volver a la salida inicial


    def update(self, boards, pacman_x, pacman_y):
        self.move(boards, pacman_x, pacman_y)
    def draw(self):
         pyxel.blt(self.x, self.y, 1, 16, 16, self.width, self.height, colkey=0)

class ghost3:
    def __init__(self, x: int = 283, y: int = 270):
        self.x = x  # Posición inicial del fantasma
        self.y = y
        self.width = 16  # Ancho de la imagen
        self.height = 16  # Alto de la imagen
        self.dx = 2  # Movimiento horizontal
        self.dy = 0
        self.start_time = pyxel.frame_count + 400

        # Objetivos iniciales
        self.target1_x = 263
        self.target1_y = 270
        self.target2_x = 263
        self.target2_y = 216
        self.current_target = 1  # Controlar cuál es el objetivo actual
        self.reached_target1 = False
        self.reached_target2 = False

        self.stopped = False
        self.stopped_timer = 300
    def move(self, boards, pacman_x, pacman_y):
        # Esperar hasta que hayan pasado 5 segundos
        if pyxel.frame_count < self.start_time:
            return

        # Moverse hacia el primer o segundo objetivo si no se han alcanzado
        if not self.reached_target1:
            self.move_to_target(self.target1_x, self.target1_y, boards)
            return
        elif not self.reached_target2:
            self.move_to_target(self.target2_x, self.target2_y, boards)
            return

        if self.stopped and self.stopped_timer > 0:
            self.stopped_timer -= 1
            if self.stopped_timer == 0:
                self.stopped = False
            return

        next_x = self.x + self.dx
        next_y = self.y + self.dy

        next_cell_x = (next_x + (16 if self.dx > 0 else 0)) // 18
        next_cell_y = (next_y + (16 if self.dy > 0 else 0)) // 18

        if boards[next_cell_y][next_cell_x] in [0, 1, 2]:
            self.x = next_x
            self.y = next_y
        else:
            self.change_direction(pacman_x, pacman_y, boards)

        if self.x >= 522 and self.dx > 0:
            self.x = 1
        elif self.x < 0:
            self.x = 540 - 1

    def move_to_target(self, target_x, target_y, boards):
        # Moverse hacia el objetivo actual
        if abs(self.x - target_x) > 2:  # Tolerancia de 2 píxeles
            self.dx = 2 if self.x < target_x else -2
            self.dy = 0
        elif abs(self.y - target_y) > 2:  # Tolerancia de 2 píxeles
            self.dy = 2 if self.y < target_y else -2
            self.dx = 0
        else:
            # Si está cerca del objetivo, detener el movimiento
            self.dx, self.dy = 0, 0

        # Calcular la siguiente posición
        next_x = self.x + self.dx
        next_y = self.y + self.dy
        next_cell_x = (next_x + (16 if self.dx > 0 else 0)) // 18
        next_cell_y = (next_y + (16 if self.dy > 0 else 0)) // 18

        # Verificar si la siguiente posición es válida (permitir celdas 0, 1, 2 y 9)
        if boards[next_cell_y][next_cell_x] in [0, 1, 2, 9]:
            self.x = next_x
            self.y = next_y

        # Verificar si ha alcanzado el objetivo actual con una tolerancia
        if abs(self.x - target_x) <= 2 and abs(self.y - target_y) <= 2:
            if self.current_target == 1:
                self.reached_target1 = True
                self.current_target = 2  # Cambiar al segundo objetivo
            elif self.current_target == 2:
                self.reached_target2 = True

    def change_direction(self, pacman_x, pacman_y, boards):
        directions = [(2, 0), (-2, 0), (0, 2), (0, -2)]
        random.shuffle(directions)

        if abs(self.x - pacman_x) > abs(self.y - pacman_y):
            if self.x < pacman_x:
                directions.insert(0, (2, 0))
            else:
                directions.insert(0, (-2, 0))
        else:
            if self.y < pacman_y:
                directions.insert(0, (0, 2))
            else:
                directions.insert(0, (0, -2))

        for dx, dy in directions:
            next_x = self.x + dx
            next_y = self.y + dy
            next_cell_x = (next_x + (16 if dx > 0 else 0)) // 18
            next_cell_y = (next_y + (16 if dy > 0 else 0)) // 18

            if boards[next_cell_y][next_cell_x] in [0, 1, 2]:
                self.dx, self.dy = dx, dy
                return

        self.dx, self.dy = 0, 0

    def reset_position(self):
        self.x = 283
        self.y = 270
        self.dx = 2
        self.dy = 0
        self.stopped = True
        self.stopped_timer = 180  # 3 segundos detenido

    def update(self, boards, pacman_x, pacman_y ):
        """Actualiza el movimiento solo si la cuenta atrás ha terminado."""
        self.move(boards, pacman_x, pacman_y)
    def draw(self):
          pyxel.blt(self.x, self.y, 1, 16, 32, self.width, self.height, colkey=0)

class ghost4:
    def __init__(self, x: int = 242, y: int = 270):
        self.x = x  # Posición inicial del fantasma
        self.y = y
        self.width = 16  # Ancho de la imagen
        self.height = 16  # Alto de la imagen
        self.dx = 2  # Movimiento horizontal
        self.dy = 0
        self.start_time = pyxel.frame_count + 600

        # Objetivos iniciales
        self.target1_x = 263
        self.target1_y = 270
        self.target2_x = 263
        self.target2_y = 216
        self.current_target = 1  # Controlar cuál es el objetivo actual
        self.reached_target1 = False
        self.reached_target2 = False

        self.stopped = False
        self.stopped_timer = 300

    def move(self, boards, pacman_x, pacman_y):
        # Esperar hasta que hayan pasado 5 segundos
        if pyxel.frame_count < self.start_time:
            return

        if not self.reached_target1:
            self.move_to_target(self.target1_x, self.target1_y, boards)
            return
        elif not self.reached_target2:
            self.move_to_target(self.target2_x, self.target2_y, boards)
            return

        if self.stopped and self.stopped_timer > 0:
            self.stopped_timer -= 1
            if self.stopped_timer == 0:
                self.stopped = False
            return

        next_x = self.x + self.dx
        next_y = self.y + self.dy

        next_cell_x = (next_x + (16 if self.dx > 0 else 0)) // 18
        next_cell_y = (next_y + (16 if self.dy > 0 else 0)) // 18

        if boards[next_cell_y][next_cell_x] in [0, 1, 2]:
            self.x = next_x
            self.y = next_y
        else:
            self.change_direction(pacman_x, pacman_y, boards)

        if self.x >= 522 and self.dx > 0:
            self.x = 1
        elif self.x < 0:
            self.x = 540 - 1

    def move_to_target(self, target_x, target_y, boards):
        # Moverse hacia el objetivo actual
        if abs(self.x - target_x) > 2:  # Tolerancia de 2 píxeles
            self.dx = 2 if self.x < target_x else -2
            self.dy = 0
        elif abs(self.y - target_y) > 2:  # Tolerancia de 2 píxeles
            self.dy = 2 if self.y < target_y else -2
            self.dx = 0
        else:
            # Si está cerca del objetivo, detener el movimiento
            self.dx, self.dy = 0, 0

        # Calcular la siguiente posición
        next_x = self.x + self.dx
        next_y = self.y + self.dy
        next_cell_x = (next_x + (16 if self.dx > 0 else 0)) // 18
        next_cell_y = (next_y + (16 if self.dy > 0 else 0)) // 18

        # Verificar si la siguiente posición es válida (permitir celdas 0, 1, 2 y 9)
        if boards[next_cell_y][next_cell_x] in [0, 1, 2, 9]:
            self.x = next_x
            self.y = next_y

        # Verificar si ha alcanzado el objetivo actual con una tolerancia
        if abs(self.x - target_x) <= 2 and abs(self.y - target_y) <= 2:
            if self.current_target == 1:
                self.reached_target1 = True
                self.current_target = 2  # Cambiar al segundo objetivo
            elif self.current_target == 2:
                self.reached_target2 = True

    def change_direction(self, pacman_x, pacman_y, boards):
        directions = [(2, 0), (-2, 0), (0, 2), (0, -2)]
        random.shuffle(directions)

        if abs(self.x - pacman_x) > abs(self.y - pacman_y):
            if self.x < pacman_x:
                directions.insert(0, (2, 0))
            else:
                directions.insert(0, (-2, 0))
        else:
            if self.y < pacman_y:
                directions.insert(0, (0, 2))
            else:
                directions.insert(0, (0, -2))

        for dx, dy in directions:
            next_x = self.x + dx
            next_y = self.y + dy
            next_cell_x = (next_x + (16 if dx > 0 else 0)) // 18
            next_cell_y = (next_y + (16 if dy > 0 else 0)) // 18

            if boards[next_cell_y][next_cell_x] in [0, 1, 2]:
                self.dx, self.dy = dx, dy
                return

        self.dx, self.dy = 0, 0

    def reset_position(self):
        self.x = 242
        self.y = 270
        self.dx = 2
        self.dy = 0
        self.stopped = True
        self.stopped_timer = 180  # 3 segundos detenido

    def update(self, boards, pacman_x, pacman_y):
        self.move(boards, pacman_x, pacman_y)

    def draw(self):
        pyxel.blt(self.x, self.y, 1, 16, 48, self.width, self.height, colkey=0)