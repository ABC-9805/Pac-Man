import pyxel
import time

class Level:
    def __init__(self, pacman, ghosts, fruits):
        self.current_level = 1
        self.score = 0
        self.pacman = pacman  # Reference to the Pac-Man object
        self.ghosts = ghosts  # List of ghost objects
        self.fruits = fruits  # List of fruit objects
        self.level_thresholds = [700, 1000, 1500, 2500]  # Score thresholds for levels
        self.ghost_speed_increment = 0.5  # How much ghost speed increases per level
        self.fruit_spawn_reduction = 1  # How much fruit spawn time reduces (in seconds)
        self.max_level = len(self.level_thresholds) + 1

    def update(self):
        """Update the level based on the current score."""
        # Check if the score exceeds the threshold for the next level
        if self.current_level < self.max_level and self.score >= self.level_thresholds[self.current_level - 1]:
            self.advance_level()

    def advance_level(self):
        """Advance to the next level and adjust game settings."""
        self.current_level += 1
        print(f"Level up! Now on level {self.current_level}")

        # Increase ghost speed
        for ghost in self.ghosts:
            ghost.dx += self.ghost_speed_increment if ghost.dx > 0 else -self.ghost_speed_increment
            ghost.dy += self.ghost_speed_increment if ghost.dy > 0 else -self.ghost_speed_increment

        # Reduce fruit spawn time
        for fruit in self.fruits:
            if hasattr(fruit, "visible_time"):
                fruit.visible_time = max(5, fruit.visible_time - self.fruit_spawn_reduction)

    def add_score(self, points):
        """Increase the player's score and check for level progression."""
        self.score += points
        self.update()

    def draw(self):
        """Display the current level and score on the screen."""
        pyxel.text(10, 5, f"Score: {self.score}", pyxel.COLOR_WHITE)
        pyxel.text(10, 15, f"Level: {self.current_level}", pyxel.COLOR_WHITE)