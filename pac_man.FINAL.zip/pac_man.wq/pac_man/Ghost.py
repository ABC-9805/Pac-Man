import pyxel
import random

class ghost1:
    def __init__(self, x: int = 263, y: int = 216):
        self.x = x
        self.y = y
        self.width = 16
        self.height = 16
        self.dx = 2
        self.dy = 0
        self.stopped = False
        self.stopped_timer = 300
        self.vulnerable = False  # New state
        self.vulnerable_timer = 0  # Timer for the state "comestible"
        self.animation_timer = 0
        self.animation_speed = 15
        self.frame = 0
        self.intermediate = False

    def move(self, boards, pacman_x, pacman_y, game_started):
        if not game_started:
            return
        else:
            if self.stopped and self.stopped_timer > 0:
                self.stopped_timer -= 1
                if self.stopped_timer == 0:
                    self.stopped = False
                return

            next_x = self.x + self.dx
            next_y = self.y + self.dy

            next_cell_x = (next_x + (16 if self.dx > 0 else 0)) // 18
            next_cell_y = (next_y + (16 if self.dy > 0 else 0)) // 18

            if boards[next_cell_y][next_cell_x] in [0, 1, 2]:
                self.x = next_x
                self.y = next_y
            else:
                if self.vulnerable:
                    flee_speed = 1
                    directions = [(flee_speed, 0), (-flee_speed, 0), (0, flee_speed), (0, -flee_speed)]
                    distances = []

                    # Calculate the distance from the ghost to Pac-Man for each direction
                    for dx, dy in directions:
                        next_x = self.x + dx
                        next_y = self.y + dy
                        next_cell_x = (next_x + (16 if dx > 0 else 0)) // 18
                        next_cell_y = (next_y + (16 if dy > 0 else 0)) // 18

                        if boards[next_cell_y][next_cell_x] in [0, 1, 2]:
                            distance = (next_x - pacman_x) ** 2 + (next_y - pacman_y) ** 2
                            distances.append((distance, dx, dy))

                    if distances:
                        # Choose the direction that maximizes the distance to Pac-Man
                        _, best_dx, best_dy = max(distances, key=lambda x: x[0])
                        self.dx, self.dy = best_dx, best_dy
                    else:
                        self.dx, self.dy = 0, 0  # Without movement if there are not valid options

                else:
                    directions = [(2, 0), (-2, 0), (0, 2), (0, -2)]
                    random.shuffle(directions)

                    if abs(self.x - pacman_x) > abs(self.y - pacman_y):
                        if self.x < pacman_x:
                            directions.insert(0, (2, 0))
                        else:
                            directions.insert(0, (-2, 0))
                    else:
                        if self.y < pacman_y:
                            directions.insert(0, (0, 2))
                        else:
                            directions.insert(0, (0, -2))

                    for dx, dy in directions:
                        next_x = self.x + dx
                        next_y = self.y + dy
                        next_cell_x = (next_x + (16 if dx > 0 else 0)) // 18
                        next_cell_y = (next_y + (16 if dy > 0 else 0)) // 18

                        if boards[next_cell_y][next_cell_x] in [0, 1, 2]:
                            self.dx, self.dy = dx, dy
                            return

                    self.dx, self.dy = 0, 0

            if self.x >= 522 and self.dx > 0:
                self.x = 1
            elif self.x < 0:
                self.x = 540 - 1

            
    def reset_position(self):
        self.x, self.y = 263, 216  # Initial position X and y
        self.stopped = True
        self.vulnerable = False  # Exit from vulnerable mode
        self.vulnerable_timer = 0
    def make_vulnerable(self):
        self.vulnerable = True
        self.vulnerable_timer = 420  # 7 seconds (60 frames per second)
    def update(self, boards, pacman_x, pacman_y, game_started):
        if not game_started:
            return

        if self.vulnerable:
            if self.vulnerable_timer > 0:
                # If 2 seconds are left for the end of the vulnerable state
                if self.vulnerable_timer < 120:  # 2 seconds at 60 FPS = 120 frames
                        self.intermediate = True  # We activate the middle animation
                else:
                    self.intermediate = False  # We desactivate the middle animation
                self.draw()  #  We draw the animation in each cycle
                self.vulnerable_timer -= 1  # We reduce the vulnerability timer
            else:
                self.vulnerable = False
                self.intermediate = False  # We assure that the middle animation deactivates
        self.move(boards, pacman_x, pacman_y, game_started)

    def draw(self):
        # Increase a timer for controlling the velocity of the animation
        self.animation_timer = (self.animation_timer + 1) % self.animation_speed

        # Only the animation changes when the timer reaches 0
        if self.animation_timer == 0:
            self.frame = (self.frame + 1) % 2

        if self.intermediate:
            pyxel.blt(self.x, self.y, 1, 32 * self.frame, 64, self.width, self.height, colkey=0)
        elif self.vulnerable:
            pyxel.blt(self.x, self.y, 1, 16, 64, self.width, self.height, colkey=0)
        elif self.dx > 0:
            pyxel.blt(self.x, self.y, 1, 16, 0, self.width, self.height, colkey=0)
        elif self.dx < 0:
            pyxel.blt(self.x, self.y, 1, 32, 0, self.width, self.height, colkey=0)
        elif self.dy > 0:
            pyxel.blt(self.x, self.y, 1, 64, 0, self.width, self.height, colkey=0)
        elif self.dy < 0:
            pyxel.blt(self.x, self.y, 1, 96, 0, self.width, self.height, colkey=0)
class ghost2:
    def __init__(self, x: int = 263, y: int = 270):
        self.x, self.y = x, y  # Initial position of ghost
        self.width, self.height = 16, 16  #Width and height of ghost
        self.dx = 2  # Horizontal movement
        self.dy = 0
        self.start_time = pyxel.frame_count + 300
        self.target_x, self.target_y = 263, 216  # Objective coordinate
        self.reached_target, self.stopped, self.vulnerable, self.intermediate = False, False, False, False  # Indicates if the objective has been reached
        self.stopped_timer = 300
        self.vulnerable_timer, self.animation_timer, self.frame = 0, 0, 0
        self.animation_speed = 15
    def move(self, boards, pacman_x, pacman_y, game_started):
        if not game_started:
            return
        else:
            # Wait until 5 seconds have passed
            if pyxel.frame_count < self.start_time:
                return

            # Move to the initial objective if it has not been reached
            if not self.reached_target:
                self.move_to_target(boards)
                return

            if self.stopped and self.stopped_timer > 0:
                self.stopped_timer -= 1
                if self.stopped_timer == 0:
                    self.stopped = False
                return

            next_x = self.x + self.dx
            next_y = self.y + self.dy

            next_cell_x = (next_x + (16 if self.dx > 0 else 0)) // 18
            next_cell_y = (next_y + (16 if self.dy > 0 else 0)) // 18

            if boards[next_cell_y][next_cell_x] in [0, 1, 2]:
                self.x = next_x
                self.y = next_y
            else:
                if self.vulnerable:
                    flee_speed = 1
                    directions = [(flee_speed, 0), (-flee_speed, 0), (0, flee_speed), (0, -flee_speed)]
                    distances = []

                    # Calcular la distancia desde el fantasma a Pac-Man para cada dirección
                    for dx, dy in directions:
                        next_x = self.x + dx
                        next_y = self.y + dy
                        next_cell_x = (next_x + (16 if dx > 0 else 0)) // 18
                        next_cell_y = (next_y + (16 if dy > 0 else 0)) // 18

                        if boards[next_cell_y][next_cell_x] in [0, 1, 2]:
                            distance = (next_x - pacman_x) ** 2 + (next_y - pacman_y) ** 2
                            distances.append((distance, dx, dy))

                    if distances:
                        # Elegir la dirección que maximice la distancia a Pac-Man
                        _, best_dx, best_dy = max(distances, key=lambda x: x[0])
                        self.dx, self.dy = best_dx, best_dy
                    else:
                        self.dx, self.dy = 0, 0
                else:
                    directions = [(2, 0), (-2, 0), (0, 2), (0, -2)]
                    random.shuffle(directions)

                    if abs(self.x - pacman_x) > abs(self.y - pacman_y):
                        if self.x < pacman_x:
                            directions.insert(0, (2, 0))
                        else:
                            directions.insert(0, (-2, 0))
                    else:
                        if self.y < pacman_y:
                            directions.insert(0, (0, 2))
                        else:
                            directions.insert(0, (0, -2))

                    for dx, dy in directions:
                        next_x = self.x + dx
                        next_y = self.y + dy
                        next_cell_x = (next_x + (16 if dx > 0 else 0)) // 18
                        next_cell_y = (next_y + (16 if dy > 0 else 0)) // 18

                        if boards[next_cell_y][next_cell_x] in [0, 1, 2]:
                            self.dx, self.dy = dx, dy
                            return

                    self.dx, self.dy = 0, 0

            if self.x >= 522 and self.dx > 0:
                self.x = 1
            elif self.x < 0:
                self.x = 540 - 1
    def move_to_target(self, boards):
        # Move towards the coordinate (263, 216)
        if self.x < self.target_x:
            self.dx, self.dy = 2, 0
        elif self.x > self.target_x:
            self.dx, self.dy = -2, 0
        elif self.y < self.target_y:
            self.dx, self.dy = 0, 2
        elif self.y > self.target_y:
            self.dx, self.dy = 0, -2

        # Calculate next position
        next_x = self.x + self.dx
        next_y = self.y + self.dy
        next_cell_x = (next_x + (16 if self.dx > 0 else 0)) // 18
        next_cell_y = (next_y + (16 if self.dy > 0 else 0)) // 18

        # Verify if the next cell is valid (permit cells 0,1,2, 9)
        if boards[next_cell_y][next_cell_x] in [0, 1, 2, 9]:
            self.x = next_x
            self.y = next_y

        # Verify if the objective has been met
        if self.x == self.target_x and self.y == self.target_y:
            self.reached_target = True  # The objective has been met
    def reset_position(self):
        self.x = 263
        self.y = 270
        self.dx = 2
        self.dy = 0
        self.stopped = True
        self.reached_target = False  # Resets the objective´s state
        self.target_x, self.target_y = 263, 216  # It will get back to the initial position
        self.vulnerable = False  # Exit the vulnerable state
        self.vulnerable_timer = 0
    def update(self, boards, pacman_x, pacman_y, game_started):
        if not game_started:
            return

        if self.vulnerable:
            if self.vulnerable_timer > 0:
                #  If there are 2 seconds left for the end of vulnerability
                if self.vulnerable_timer < 120:  # 2 seconds at 60 FPS = 120 frames
                    self.intermediate = True  # We activate the middle animation
                else:
                    self.intermediate = False  # We deactivate the middle animation
                self.draw()  # We draw the animation for each cycle
                self.vulnerable_timer -= 1  #We reduce the vulerability timer
            else:
                self.vulnerable = False
                self.intermediate = False  #We assure that the middle animation is deactivated
        self.move(boards, pacman_x, pacman_y, game_started)

    def make_vulnerable(self):
        self.vulnerable = True
        self.vulnerable_timer = 420
    def draw(self):
        # Increases the timer for controlling the velocity of the animation
        self.animation_timer = (self.animation_timer + 1) % self.animation_speed

        #Only the animation changes when the timer reaches 0
        if self.animation_timer == 0:
            self.frame = (self.frame + 1) % 2

        if self.intermediate:
            pyxel.blt(self.x, self.y, 1, 32 * self.frame, 64, self.width, self.height, colkey=0)
        elif self.vulnerable:
            pyxel.blt(self.x, self.y, 1, 16, 64, self.width, self.height, colkey=0)
        elif self.dx > 0:
            pyxel.blt(self.x, self.y, 1, 16, 16, self.width, self.height, colkey=0)
        elif self.dx < 0:
            pyxel.blt(self.x, self.y, 1, 32, 16, self.width, self.height, colkey=0)
        elif self.dy > 0:
            pyxel.blt(self.x, self.y, 1, 64, 16, self.width, self.height, colkey=0)
        elif self.dy < 0:
            pyxel.blt(self.x, self.y, 1, 96, 16, self.width, self.height, colkey=0)

class ghost3:
    def __init__(self, x: int = 283, y: int = 270):
        self.x, self.y = x, y  # Initial position of ghost
        self.width, self.height = 16, 16  # Width and height of image
        self.dx = 2  # Horizontal movement
        self.dy = 0
        self.start_time = pyxel.frame_count + 500
        self.target1_x, self.target1_y = 263, 270
        self.target2_x, self.target2_y = 263, 216
        self.current_target = 1  #Control which is the actual objective
        self.reached_target1, self.reached_target2, self.stopped, self.vulnerable, self.intermediate = False, False, False, False, False
        self.vulnerable = False  # New state
        self.vulnerable_timer, self.animation_timer, self.frame = 0, 0, 0
        self.animation_speed = 15
        self.stopped_timer = 180

    def move(self, boards, pacman_x, pacman_y, game_started):
        if not game_started:
            return
        else:
            #Wait until 5 seconds have passed
            if pyxel.frame_count < self.start_time:
                return

            #Move to the first or second objective if it has not been reached

            if self.current_target == 1 and not self.reached_target1:
                self.move_to_target(self.target1_x, self.target1_y, boards)
            elif self.current_target == 2 and not self.reached_target2:
                self.move_to_target(self.target2_x, self.target2_y, boards)


            #If it has stopped, wait until the timer is done
            if self.stopped and self.stopped_timer > 0:
                self.stopped_timer -= 1
                if self.stopped_timer == 0:
                    self.stopped = False
                return

            next_x = self.x + self.dx
            next_y = self.y + self.dy

            next_cell_x = (next_x + (16 if self.dx > 0 else 0)) // 18
            next_cell_y = (next_y + (16 if self.dy > 0 else 0)) // 18

            # Verify if the next position is valid (let cells 0,1,2)
            if boards[next_cell_y][next_cell_x] in [0, 1, 2]:
                self.x = next_x
                self.y = next_y
            else:
                # If the ghost is vulnerable, escape from Pac-man, on the contrary, change Pac-Man´s direction
                if self.vulnerable:
                    flee_speed = 1
                    directions = [(flee_speed, 0), (-flee_speed, 0), (0, flee_speed), (0, -flee_speed)]
                    distances = []

                    # Calculate the distance from Pac-Man for each direction
                    for dx, dy in directions:
                        next_x = self.x + dx
                        next_y = self.y + dy
                        next_cell_x = (next_x + (16 if dx > 0 else 0)) // 18
                        next_cell_y = (next_y + (16 if dy > 0 else 0)) // 18

                        if boards[next_cell_y][next_cell_x] in [0, 1, 2]:
                            distance = (next_x - pacman_x) ** 2 + (next_y - pacman_y) ** 2
                            distances.append((distance, dx, dy))

                    if distances:
                        # Choose the direction that maximices the distance to Pac-Man
                        _, best_dx, best_dy = max(distances, key=lambda x: x[0])
                        self.dx, self.dy = best_dx, best_dy
                    else:
                        self.dx, self.dy = 0, 0
                else:
                    #Change the direction to follow Pac-Man
                    directions = [(2, 0), (-2, 0), (0, 2), (0, -2)]
                    random.shuffle(directions)

                    if abs(self.x - pacman_x) > abs(self.y - pacman_y):
                        if self.x < pacman_x:
                            directions.insert(0, (2, 0))
                        else:
                            directions.insert(0, (-2, 0))
                    else:
                        if self.y < pacman_y:
                            directions.insert(0, (0, 2))
                        else:
                            directions.insert(0, (0, -2))

                    for dx, dy in directions:
                        next_x = self.x + dx
                        next_y = self.y + dy
                        next_cell_x = (next_x + (16 if dx > 0 else 0)) // 18
                        next_cell_y = (next_y + (16 if dy > 0 else 0)) // 18

                        if boards[next_cell_y][next_cell_x] in [0, 1, 2]:
                            self.dx, self.dy = dx, dy
                            return

                    self.dx, self.dy = 0, 0

            if self.x >= 522 and self.dx > 0:
                    self.x = 1
            elif self.x < 0:
                self.x = 540 - 1
    def move_to_target(self, target_x, target_y, boards):
        # Move to the actual objective
        if abs(self.x - target_x) > 2:  # Toleration of 2 pyxels
            self.dx = 2 if self.x < target_x else -2
            self.dy = 0
        elif abs(self.y - target_y) > 2:  # Toleration of 2 pyxels
            self.dy = 2 if self.y < target_y else -2
            self.dx = 0
        else:
            # If it is near the objective, stop the movement
            self.dx, self.dy = 0, 0

        # Calculate the next position
        next_x = self.x + self.dx
        next_y = self.y + self.dy
        next_cell_x = (next_x + (16 if self.dx > 0 else 0)) // 18
        next_cell_y = (next_y + (16 if self.dy > 0 else 0)) // 18

        # Verify if the next position is valid (let cells 0,1,2,9)
        if boards[next_cell_y][next_cell_x] in [0, 1, 2, 9]:
            self.x = next_x
            self.y = next_y

        #Verify if the actual objective has been reached with a tolerance
        if abs(self.x - target_x) <= 2 and abs(self.y - target_y) <= 2:
            if self.current_target == 1:
                self.reached_target1 = True
                self.current_target = 2  # Change to the next objective
            elif self.current_target == 2:
                self.reached_target2 = True
    def reset_position(self):
        self.x = 283
        self.y = 270
        self.stopped = 180
        self.dx = -2
        self.dy = 0
        self.stopped = True
        self.vulnerable = False  #Exit the vulnerability mode
        self.vulnerable_timer = 0
        #  Reset the reached objectives
        self.reached_target1 = False
        self.reached_target2 = False

    def update(self, boards, pacman_x, pacman_y, game_started):
        if not game_started:
            return

        if self.vulnerable:
            if self.vulnerable_timer > 0:
                #If there are 2 seconds left for the final of vulnerability
                if self.vulnerable_timer < 120:  # 2 seconds at 60 FPS = 120 frames
                    self.intermediate = True  # We activate the middle animation
                else:
                    self.intermediate = False  #  We deactivate the middle animation
                self.draw()  # We draw the animation in each cycle
                self.vulnerable_timer -= 1  # We reduce the vulnerability´s timer
            else:
                self.vulnerable = False
                self.intermediate = False  # We assure that the middle animation is deactivated
        self.move(boards, pacman_x, pacman_y, game_started)
    def make_vulnerable(self):
        self.vulnerable = True
        self.vulnerable_timer = 420
    def draw(self):
        # Increase a timer to control the velocity of the animation
        self.animation_timer = (self.animation_timer + 1) % self.animation_speed

        #Only the animation changes when the timer reaches 0
        if self.animation_timer == 0:
            self.frame = (self.frame + 1) % 2

        if self.intermediate:
            pyxel.blt(self.x, self.y, 1, 32 * self.frame, 64, self.width, self.height, colkey=0)
        elif self.vulnerable:
            pyxel.blt(self.x, self.y, 1, 16, 64, self.width, self.height, colkey=0)
        elif self.dx > 0:
            pyxel.blt(self.x, self.y, 1, 16, 32, self.width, self.height, colkey=0)
        elif self.dx < 0:
            pyxel.blt(self.x, self.y, 1, 32, 32, self.width, self.height, colkey=0)
        elif self.dy > 0:
            pyxel.blt(self.x, self.y, 1, 64, 32, self.width, self.height, colkey=0)
        elif self.dy < 0:
            pyxel.blt(self.x, self.y, 1, 96, 32, self.width, self.height, colkey=0)
class ghost4:
    def __init__(self, x: int = 242, y: int = 270):
        self.x = x  # Initial position of the ghost
        self.y = y
        self.width = 16  # Width of the image
        self.height = 16  # Height of the image
        self.dx = 2  # Horizontal movement
        self.dy = 0
        self.start_time = pyxel.frame_count + 700

        # Initial objectives
        self.target1_x = 263
        self.target1_y = 270
        self.target2_x = 263
        self.target2_y = 216
        self.current_target = 1  # Control what the actual objective is
        self.reached_target1 = False
        self.reached_target2 = False

        self.stopped = False
        self.stopped_timer = 300

        self.vulnerable = False  # New state
        self.vulnerable_timer = 0

        self.intermediate = False
        self.animation_timer = 0
        self.animation_speed = 15
        self.frame = 0
    def move(self, boards, pacman_x, pacman_y, game_started):
        if not game_started:
            return
        else:
            # Wait until 5 seconds have passed
            if pyxel.frame_count < self.start_time:
                return

            if not self.reached_target1:
                self.move_to_target(self.target1_x, self.target1_y, boards)
                return
            elif not self.reached_target2:
                self.move_to_target(self.target2_x, self.target2_y, boards)
                return

            if self.stopped and self.stopped_timer > 0:
                self.stopped_timer -= 1
                if self.stopped_timer == 0:
                    self.stopped = False
                return

            next_x = self.x + self.dx
            next_y = self.y + self.dy

            next_cell_x = (next_x + (16 if self.dx > 0 else 0)) // 18
            next_cell_y = (next_y + (16 if self.dy > 0 else 0)) // 18

            if boards[next_cell_y][next_cell_x] in [0, 1, 2]:
                self.x = next_x
                self.y = next_y
            else:
                if self.vulnerable:
                    if self.vulnerable:
                        # Flee logic (escape from Pac-Man)
                        flee_speed = 1
                        directions = [(flee_speed, 0), (-flee_speed, 0), (0, flee_speed), (0, -flee_speed)]
                        distances = []

                        # Calculate the distance from the ghost to Pac-man for each direction
                        for dx, dy in directions:
                            next_x = self.x + dx
                            next_y = self.y + dy
                            next_cell_x = (next_x + (16 if dx > 0 else 0)) // 18
                            next_cell_y = (next_y + (16 if dy > 0 else 0)) // 18

                            if boards[next_cell_y][next_cell_x] in [0, 1, 2]:
                                distance = (next_x - pacman_x) ** 2 + (next_y - pacman_y) ** 2
                                distances.append((distance, dx, dy))

                        if distances:
                            #Choose the direction that maximizes the distance to Pac-Man
                            _, best_dx, best_dy = max(distances, key=lambda x: x[0])
                            self.dx, self.dy = best_dx, best_dy
                        else:
                            self.dx, self.dy = 0, 0
                else:
                    # Change direction logic (go after Pac-Man)
                    directions = [(2, 0), (-2, 0), (0, 2), (0, -2)]
                    random.shuffle(directions)

                    if abs(self.x - pacman_x) > abs(self.y - pacman_y):
                        if self.x < pacman_x:
                            directions.insert(0, (2, 0))
                        else:
                            directions.insert(0, (-2, 0))
                    else:
                        if self.y < pacman_y:
                            directions.insert(0, (0, 2))
                        else:
                            directions.insert(0, (0, -2))

                    for dx, dy in directions:
                        next_x = self.x + dx
                        next_y = self.y + dy
                        next_cell_x = (next_x + (16 if dx > 0 else 0)) // 18
                        next_cell_y = (next_y + (16 if dy > 0 else 0)) // 18

                        if boards[next_cell_y][next_cell_x] in [0, 1, 2]:
                            self.dx, self.dy = dx, dy
                            return

                    self.dx, self.dy = 0, 0

            if self.x >= 522 and self.dx > 0:
                self.x = 1
            elif self.x < 0:
                self.x = 540 - 1
    def move_to_target(self, target_x, target_y, boards):
        # Move to the actual objective
        if abs(self.x - target_x) > 2:  # Tolerance of 2 píxeles
            self.dx = 2 if self.x < target_x else -2
            self.dy = 0
        elif abs(self.y - target_y) > 2:  # Tolerance of 2 píxeles
            self.dy = 2 if self.y < target_y else -2
            self.dx = 0
        else:
            #If it is near the objective, stop the movement
            self.dx, self.dy = 0, 0

        # Calculate the next position
        next_x = self.x + self.dx
        next_y = self.y + self.dy
        next_cell_x = (next_x + (16 if self.dx > 0 else 0)) // 18
        next_cell_y = (next_y + (16 if self.dy > 0 else 0)) // 18

        # Verify if the next position is valid (let cells 0,1,2,9)
        if boards[next_cell_y][next_cell_x] in [0, 1, 2, 9]:
            self.x = next_x
            self.y = next_y

        # Verify if the actual objective has been reached with a tolerance
        if abs(self.x - target_x) <= 2 and abs(self.y - target_y) <= 2:
            if self.current_target == 1:
                self.reached_target1 = True
                self.current_target = 2  # Change to the next objective
            elif self.current_target == 2:
                self.reached_target2 = True
    def reset_position(self):
        self.x, self.y = 242, 270
        self.dx, self.dy = 2, 0
        self.stopped = True
        self.reached_target1, self.reached_target2 = False, False
        self.current_target = 1  # Reset to the first objective
        self.vulnerable = False  # Exit the vulnerable mode
        self.vulnerable_timer = 0
    def update(self, boards, pacman_x, pacman_y, game_started):
        if not game_started:
            return

        if self.vulnerable:
            if self.vulnerable_timer > 0:
                # If there are 2 seconds left for the final of the vulnerability
                if self.vulnerable_timer < 120:  # 2 seconds at 60 FPS = 120 frames
                    self.intermediate = True  # We activate the middle animation
                else:
                    self.intermediate = False  # We deactivate the middle animation
                self.draw()  # We draw the animation in each cycle
                self.vulnerable_timer -= 1  # We reduce the vulnerability timer
            else:
                self.vulnerable = False
                self.intermediate = False  # We assure that the middle animation is deactivated
        self.move(boards, pacman_x, pacman_y, game_started)
    def make_vulnerable(self):
        self.vulnerable = True
        self.vulnerable_timer = 420
    def draw(self):
        # Increase a timer for controlling the velocity of the animation
        self.animation_timer = (self.animation_timer + 1) % self.animation_speed

        # Only the animation changes when the timer reaches 0
        if self.animation_timer == 0:
            self.frame = (self.frame + 1) % 2

        if self.intermediate:
            pyxel.blt(self.x, self.y, 1, 32 * self.frame, 64, self.width, self.height, colkey=0)
        elif self.vulnerable:
            # Animation "comestible"
            pyxel.blt(self.x, self.y, 1, 16, 64, self.width, self.height, colkey=0)
        elif self.dx > 0:
            pyxel.blt(self.x, self.y, 1, 16, 48, self.width, self.height, colkey=0)
        elif self.dx < 0:
            pyxel.blt(self.x, self.y, 1, 32, 48, self.width, self.height, colkey=0)
        elif self.dy > 0:
            pyxel.blt(self.x, self.y, 1, 64, 48, self.width, self.height, colkey=0)
        elif self.dy < 0:
            pyxel.blt(self.x, self.y, 1, 96, 48, self.width, self.height, colkey=0)
