import pyxel
import time



class Pacman:
    def __init__(self, x: int = 263, y: int = 432):
        self.x = x  # Initial position of Pac-Man
        self.y = y
        self.width = 16  # Width of Pac-Man's image
        self.height = 16  # Height of Pac-man's image
        self.dx = 2  # Horizontal movement (2 pixels per frame)
        self.dy = 0 # Vertical movement (initially it does not move vertically)
        self.score = 0 # Pac-Man's score
        self.lives = 3 #Pac-Man's initial lives
        self.countdown_timer = 0
        self.frame = 0
        self.animation_timer = 0
        self.animation_speed = 4
        self.initial_x = x #used to keep the initial position of pacman
        self.initial_y = y
        self.initial_dx = self.dx #used to keep the initial position of pacman


    def reset_position(self,reset_direction=False):
        self.x = self.initial_x
        self.y = self.initial_y
        #if reset_direction is True, we keep the initial direction (to the right)
        if reset_direction:
            self.dx = 2
            self.dy = 0
    #this function is used to reset the position of Pac-man

    def move(self, boards, ghosts):
        #if the countdown timer is greater than 0, decrement it and return (no movement)
        if self.countdown_timer > 0:
            self.countdown_timer -= 1
            return
        #store the previous direction (dx,dy)
        prev_dx, prev_dy = self.dx, self.dy
        #initialize the new direction (dx,dy) to be the same as the current one
        next_dx, next_dy = self.dx, self.dy

        #check for the user input and set next direction based on the key pressed
        if pyxel.btn(pyxel.KEY_RIGHT): #if the RIGHT arrow key is pressed
            next_dx, next_dy = 2, 0 #move right
        elif pyxel.btn(pyxel.KEY_LEFT): #if the LEFT arrow key is pressed
            next_dx, next_dy = -2, 0 #move left
        elif pyxel.btn(pyxel.KEY_UP): #if the UP arrow key is pressed
            next_dx, next_dy = 0, -2 #move up
        elif pyxel.btn(pyxel.KEY_DOWN): #if the DOWN arrow key is pressed
            next_dx, next_dy = 0, 2 #move down


        # if the next direction is different from the current one, adjust the position
        if next_dx != self.dx or next_dy != self.dy:
            #if moving horizontally, align the y-coordinate to the nearest grid
            if next_dx != 0:
                self.y = (self.y // 18) * 18
            #if moving vertically, align the x-coordinate to the nearest grid
            elif next_dy != 0:
                self.x = (self.x // 18) * 18
        #calculate the next position based on the new direction
        next_x = self.x + next_dx
        next_y = self.y + next_dy
        #calculate the next grid cell that the player will move to
        next_cell_x = (next_x + (16 if next_dx > 0 else 0)) // 18
        next_cell_y = (next_y + (16 if next_dy > 0 else 0)) // 18
        #check if the next cell is walkable (it should be 0,1,or2)
        if boards[next_cell_y][next_cell_x] in [0, 1, 2]:
            #if the move is valid, update the player´s position and direction
            self.x = next_x
            self.y = next_y
            self.dx, self.dy = next_dx, next_dy
            #if the player collected a dot (represented by 1), increase the score by 10
            if boards[next_cell_y][next_cell_x] == 1:
                self.score += 10
                boards[next_cell_y][next_cell_x] = 0 #remove the dot from the board

            #if the player collected a power pellet (represented by 2), increase the score by 50
            elif boards[next_cell_y][next_cell_x] == 2:
                self.score += 50
                boards[next_cell_y][next_cell_x] = 0 #remove the power pellet from the board
                #make all ghosts vulnerable
                for ghost in ghosts:
                    ghost.make_vulnerable()

        else:
            #if the next cell is not valid, revert the direction to the previous one
            self.dx, self.dy = prev_dx, prev_dy

        #if the player moves beyond the right edge of the screen, wrap around to the left side
        if self.x >= 522 and self.dx > 0:
            self.x = 1 #wrap to the left side of the screen
        #if the player moves beyond the left edge of the screen, wrap around to the right side
        elif self.x < 0:
            self.x = 540 - 1 #wrap to the right side of the screen

    def check_collision(self, ghosts, fruit):
        for ghost in ghosts:
            if abs(self.x - ghost.x) < 16 and abs(self.y - ghost.y) < 16:
                if ghost.vulnerable:
                    # Sumar 400 puntos si el fantasma está en modo vulnerable
                    self.score += 400
                    ghost.reset_position()
                else:
                    self.lives -= 1
                    self.start_countdown()
                    ghost.reset_position()
                    if self.lives > 0:
                        self.reset_position(reset_direction=True)  # asegura que vuelva también a su dirección
                    if self.lives <= 0:
                        print("Game Over")
                        pyxel.quit()
                    for ghost in ghosts:
                        ghost.reset_position()

            # Verificar la colisión con la fruta
        if fruit.visible and abs(self.x - fruit.x) < 16 and abs(self.y - fruit.y) < 16:
            self.score += 200
            fruit.visible = False  # Haz que la fruta desaparezca
            fruit.spawn_time = time.time()  # Reinicia el temporizador para la fruta

    def start_countdown(self):
        self.countdown_timer = 180

    def update(self, boards, ghosts, fruit):
        self.move(boards, ghosts)
        self.check_collision(ghosts, fruit)

    def draw(self):
        # Incrementa un contador para controlar la velocidad de la animación
        self.animation_timer = (self.animation_timer + 1) % self.animation_speed

        # Solo cambia el cuadro de animación cuando el contador llega a 0
        if self.animation_timer == 0:
            self.frame = (self.frame + 1) % 3  # Alterna entre 0, 1 y 2

        # Cambiar el frame de la boca según la dirección de movimiento
        if self.dx > 0:
            pyxel.blt(self.x, self.y, 0, 16 * self.frame, 0, self.width, self.height, colkey=0)
        elif self.dx < 0:
            pyxel.blt(self.x, self.y, 0, 16 * self.frame, 16, self.width, self.height, colkey=0)
        elif self.dy > 0:
            pyxel.blt(self.x, self.y, 0, 16 * self.frame, 48, self.width, self.height, colkey=0)
        elif self.dy < 0:
            pyxel.blt(self.x, self.y, 0, 16 * self.frame, 32, self.width, self.height, colkey=0)
        # Llama a la función para dibujar "Score" en letras grandes
        pyxel.text(8, 6, f"SCORE:{self.score}", 7, None)
        pyxel.text(8, 20, f"LIVES:{self.lives}", 7, None)  # Dibujar vidas